package com.hfad.informationgarmenfactory;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class SpecializationActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_specialization);
    }

    public void onClack(View view) {
        Intent intent = new Intent(SpecializationActivity.this, MainActivity.class);
        startActivity(intent);
    }
}
